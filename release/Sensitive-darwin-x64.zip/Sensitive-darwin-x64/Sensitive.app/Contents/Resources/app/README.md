# sensitive
A native version of the kibana sense plugin
